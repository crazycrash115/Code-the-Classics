"""
Pygame Zero entrypoint (project root).

This project’s assets are in:
  cavern-master/images/
  cavern-master/sounds/
  cavern-master/music/

But the original Cavern code uses some sprite names that don’t exist as files
in this repo (ex: "fruit", "pop3", "blow6", "orb00", "player15").

Instead of renaming assets or rewriting all game logic, we patch the Pygame Zero
image loader to translate old names -> actual filenames at runtime.
"""

from pathlib import Path
from pgzero import loaders

from src.app import App

# Make sure pgzero is rooted at the project directory (where images/ exists)
PROJECT_ROOT = Path(__file__).resolve().parent
loaders.set_root(str(PROJECT_ROOT))


def _install_image_aliases() -> None:
    alias: dict[str, str] = {}

    # ---------------------------------------------------------------------
    # Player sprites
    # Files you have: run00..run03, run10..run13, jump0/jump1, blow0/blow1, still
    # Code may ask for: player01..player18 etc
    # ---------------------------------------------------------------------
    alias["player8"] = "still"

    for dir_idx in (0, 1):
        # Run cycle (we only need a few frames, map to what exists)
        alias[f"player{dir_idx}1"] = f"run{dir_idx}0"
        alias[f"player{dir_idx}2"] = f"run{dir_idx}1"
        alias[f"player{dir_idx}3"] = f"run{dir_idx}2"

        # Jump frame
        alias[f"player{dir_idx}4"] = f"jump{dir_idx}"

        # Blow frames: original code may request 5..8; you only have blow0/blow1
        for frame in (5, 6, 7, 8):
            alias[f"player{dir_idx}{frame}"] = f"blow{dir_idx}"

    # ---------------------------------------------------------------------
    # Fruit sprite
    # Files you have: fruit00..fruit42 (no fruit.png)
    # Code asks: "fruit"
    # ---------------------------------------------------------------------
    alias["fruit"] = "fruit00"

    # ---------------------------------------------------------------------
    # Pop sprite
    # Files you have: pop00..pop06 and pop10..pop16 (no pop0.png)
    # Code asks: "pop0".."pop6"
    # We'll map to pop00..pop06
    # ---------------------------------------------------------------------
    for i in range(0, 10):
        alias[f"pop{i}"] = f"pop0{i}"

    # ---------------------------------------------------------------------
    # Blow animation (used by Orb early frames)
    # Files you have: blow0, blow1
    # Code asks: blow0..blow6
    # We'll alternate between blow0/blow1
    # ---------------------------------------------------------------------
    for i in range(0, 10):
        alias[f"blow{i}"] = f"blow{i % 2}"

    # ---------------------------------------------------------------------
    # Orb trapped-enemy animation
    # Files you have: orb0..orb6
    # Code asks: orb00..orb13 (type 0/1 + frame 0..3)
    # We'll map those 8 names into the 7-frame orb strip you have.
    # ---------------------------------------------------------------------
    alias["orb00"] = "orb0"
    alias["orb01"] = "orb1"
    alias["orb02"] = "orb2"
    alias["orb03"] = "orb3"
    alias["orb10"] = "orb4"
    alias["orb11"] = "orb5"
    alias["orb12"] = "orb6"
    alias["orb13"] = "orb6"

    original_load = loaders.images.load

    def patched_load(name: str, *args, **kwargs):
        # 1) Try normal load first
        try:
            return original_load(name, *args, **kwargs)
        except KeyError:
            pass

        # 2) Direct alias mapping
        mapped = alias.get(name)
        if mapped is not None:
            return original_load(mapped, *args, **kwargs)

        # 3) Generic zero-pad fallback:
        #    if code asks "pop3" and file is "pop03" or "pop03.png" style
        #    (your repo uses pop00, fruit00 etc)
        #
        # NOTE: We only do this if the original failed, so it won't override real files.
        if len(name) >= 2 and name[-1].isdigit() and name[-2].isalpha():
            candidate = f"{name[:-1]}0{name[-1]}"
            try:
                return original_load(candidate, *args, **kwargs)
            except KeyError:
                pass

        # 4) No mapping found, re-raise the original error message
        #    (best for debugging the next missing name)
        return original_load(name, *args, **kwargs)

    loaders.images.load = patched_load


_install_image_aliases()

app = App()

def update():
    app.update()

def draw():
    app.draw(screen)
